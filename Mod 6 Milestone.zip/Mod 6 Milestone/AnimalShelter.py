from pymongo import MongoClient
import logging

class AnimalShelter:
    """
    CRUD operations for the Animal collection in MongoDB
    """

    def __init__(self, username, password):
        """
        Initialize the MongoDB connection with authentication.
        """
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 33421
        DB = 'AAC'
        COL = 'animals'

        try:
            self.client = MongoClient(f'mongodb://{username}:{password}@{HOST}:{PORT}')
            self.database = self.client[DB]
            self.collection = self.database[COL]
            logging.info("MongoDB connection successful.")
        except Exception as e:
            raise Exception(f"Error connecting to MongoDB: {e}")

    def create(self, data):
        """
        Insert a document into the MongoDB collection.
        """
        if data and isinstance(data, dict):
            try:
                insert_status = self.collection.insert_one(data)
                logging.info(f"Insert acknowledged: {insert_status.acknowledged}")
                return insert_status.acknowledged
            except Exception as e:
                logging.error(f"Error during insert: {e}")
                return False
        else:
            logging.warning("Invalid data provided for insert operation.")
            return False

    def read(self, query_data):
        """
        Query documents from the MongoDB collection.
        """
        if query_data is not None and isinstance(query_data, dict):
            try:
                result = self.collection.find(query_data, {"_id": False})
                return list(result)
            except Exception as e:
                raise Exception(f"Error during read operation: {e}")
        else:
            raise ValueError("Invalid query data provided for read operation.")

    def update(self, query_data, update_data):
        """
        Update documents in the MongoDB collection.
        """
        if query_data and update_data and isinstance(query_data, dict) and isinstance(update_data, dict):
            try:
                result = self.collection.update_many(query_data, {"$set": update_data})
                logging.info(f"Matched: {result.matched_count}, Modified: {result.modified_count}")
                return {"matched_count": result.matched_count, "modified_count": result.modified_count}
            except Exception as e:
                logging.error(f"Error during update: {e}")
                return None
        else:
            logging.warning("Invalid query or update data provided for update operation.")
            return None

    def delete(self, query_data):
        """
        Delete documents from the MongoDB collection.
        """
        if query_data and isinstance(query_data, dict):
            try:
                delete_result = self.collection.delete_many(query_data)
                logging.info(f"Documents deleted: {delete_result.deleted_count}")
                return delete_result.deleted_count > 0
            except Exception as e:
                logging.error(f"Error during delete: {e}")
                return False
        else:
            logging.warning("Invalid query data provided for delete operation.")
            return False
